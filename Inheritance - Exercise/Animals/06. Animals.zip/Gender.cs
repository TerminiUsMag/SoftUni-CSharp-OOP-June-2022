﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public enum Gender
    {
        Male,
        Female
    }
}
