﻿namespace BorderControl
{
    public interface IBirthdayable
    {
        public string BirthDate { get; set; }
        string GetBirthYear();
    }
}